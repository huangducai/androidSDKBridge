package com.nearme.onlinesdk.demo;

import com.nearme.game.sdk.GameCenterSDK;
import com.nearme.game.sdk.common.util.AppUtil;
import android.app.Application;

public class MyApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
		String appSecret = "e2eCa732422245E8891F6555e999878B";
		GameCenterSDK.init(appSecret, this);
	}
}
